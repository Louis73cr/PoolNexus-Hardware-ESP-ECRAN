var main_8cpp =
[
    [ "NUM_PAGES", "main_8cpp.html#ae12c40b3b2496ea64cbd1f626d4a5817", null ],
    [ "PAGE_HOME", "main_8cpp.html#a49302fd0bca0e066868a023b25727629", null ],
    [ "PAGE_MENU", "main_8cpp.html#a83d8bc07c085947928f386d9fc437897", null ],
    [ "PAGE_SETTINGS", "main_8cpp.html#ae7ba34d0d5715122f53abfc6419dc0c9", null ],
    [ "PAGE_STATUS", "main_8cpp.html#a0afdaaa59b862cd2aba062ea43be4520", null ],
    [ "loop", "main_8cpp.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "main_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "screen", "main_8cpp.html#acc3669541c3c84d5981955c4c04656da", null ],
    [ "touch", "main_8cpp.html#a7a40137711116077b8f14c0d0a64f3da", null ]
];