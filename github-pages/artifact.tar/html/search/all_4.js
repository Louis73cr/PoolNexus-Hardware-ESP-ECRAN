var searchData=
[
  ['screen_0',['screen',['../main_8cpp.html#acc3669541c3c84d5981955c4c04656da',1,'main.cpp']]],
  ['setup_1',['setup',['../main_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'main.cpp']]]
];
