var searchData=
[
  ['num_5fpages_0',['NUM_PAGES',['../main_8cpp.html#ae12c40b3b2496ea64cbd1f626d4a5817',1,'main.cpp']]]
];
