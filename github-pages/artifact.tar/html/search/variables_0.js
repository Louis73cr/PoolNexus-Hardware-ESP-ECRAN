var searchData=
[
  ['screen_0',['screen',['../main_8cpp.html#acc3669541c3c84d5981955c4c04656da',1,'main.cpp']]]
];
