var searchData=
[
  ['page_5fhome_0',['PAGE_HOME',['../main_8cpp.html#a49302fd0bca0e066868a023b25727629',1,'main.cpp']]],
  ['page_5fmenu_1',['PAGE_MENU',['../main_8cpp.html#a83d8bc07c085947928f386d9fc437897',1,'main.cpp']]],
  ['page_5fsettings_2',['PAGE_SETTINGS',['../main_8cpp.html#ae7ba34d0d5715122f53abfc6419dc0c9',1,'main.cpp']]],
  ['page_5fstatus_3',['PAGE_STATUS',['../main_8cpp.html#a0afdaaa59b862cd2aba062ea43be4520',1,'main.cpp']]]
];
